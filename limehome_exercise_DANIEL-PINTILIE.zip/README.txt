How to run the script:

1. Install python3 (Script tested with python 3.8.10)

2. Install python3 dependencies ()

pip3 install -r requirmenets.txt

3. Export your AWS environment variables in your terminal:

export AWS_ACCESS_KEY_ID='your_access_key_id'
export AWS_SECRET_ACCESS_KEY='your_secret_access_key'
export AWS_DEFAULT_REGION='your_region'

4. Run the script:

python3 file_search.py <bucket_name> <substring>

Answers:

Infrastructure as Code

    Infrastrucure as Code abbreviated as IaC is a concept which allows programmers (usually DevOps / DevSecOps / Cloud Engineers / Infrastructure Engineers)
to create, provision, manage and maintain cloud infrastructure using code. A couple of popular tools were developed to support Iac: Terraform, OpenTofu, Pulumi, Ansible etc.
Utilizing IaC is paramount for enhancing automation, maintainability, and reusability of infrastructure in a company.

Observability

    Observability is the ability to monitor the behaviour of the microservices and the platform they run on. Microservices architecture involve many small, decoupled services that interact with each other.
Using logging, dashboard, alerts, traces, metrics, events tools to gain insights into how these services perform, how they interact, and where issues might arise is crucial. Observability helps a lot with
troubleshooting, performance monitoring, dependency tracking, error tracing and in managing the complexity of the microservices architecture.

Security

    First things that I would check in an AWS environemnt in terms of security are:

    1. Security Groups and NACLs -- Ensure that rules are restrictive and only allow necessary traffic.
    2. IAM (policies and roles) -- Ensure that only necessary users and roles exist and that they adhere to the principle of least privilege. Check attached policies to ensure they grant the minimum necessary permissions
    3. S3 Buckets policies -- Ensure they are not exposed publicly if not necessary
    4. Any WAF rules or usage -- Whitelisted / Blacklisted IPs and Rules
